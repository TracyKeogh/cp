import React from 'react';
import { 
  BarChart3, 
  Heart, 
  ImageIcon, 
  Target, 
  Calendar as CalendarIcon,
  Home,
  ChevronRight
} from 'lucide-react';
import type { ViewType } from '../App';

interface NavigationProps {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
}

const Navigation: React.FC<NavigationProps> = ({ currentView, onNavigate }) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home, color: 'text-slate-600' },
    { id: 'wheel', label: 'Wheel of Life', icon: BarChart3, color: 'text-purple-600' },
    { id: 'values', label: 'Values Clarity', icon: Heart, color: 'text-red-500' },
    { id: 'vision', label: 'Vision Board', icon: ImageIcon, color: 'text-teal-600' },
    { id: 'goals', label: 'Goals', icon: Target, color: 'text-orange-500' },
    { id: 'calendar', label: 'Calendar', icon: CalendarIcon, color: 'text-indigo-600' },
  ];

  return (
    <nav className="fixed left-0 top-20 w-64 h-[calc(100vh-5rem)] bg-white shadow-lg border-r border-slate-200 overflow-y-auto">
      <div className="p-6">
        <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-4">
          Your Journey
        </h2>
        <ul className="space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            
            return (
              <li key={item.id}>
                <button
                  onClick={() => onNavigate(item.id as ViewType)}
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition-all duration-200 group ${
                    isActive 
                      ? 'bg-purple-50 text-purple-700 shadow-sm' 
                      : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <Icon className={`w-5 h-5 ${isActive ? 'text-purple-600' : item.color}`} />
                    <span className="font-medium">{item.label}</span>
                  </div>
                  <ChevronRight className={`w-4 h-4 transition-transform ${
                    isActive ? 'text-purple-500 transform rotate-90' : 'text-slate-400 group-hover:text-slate-600'
                  }`} />
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
};

export default Navigation;