import React, { useState } from 'react';
import { Target, Calendar, CheckCircle2, Circle, Plus, TrendingUp, Clock, Award } from 'lucide-react';

interface Goal {
  id: string;
  title: string;
  description: string;
  level: 'vision' | 'annual' | 'quarterly' | 'weekly' | 'daily';
  status: 'not-started' | 'in-progress' | 'completed';
  progress: number;
  dueDate?: string;
  parentId?: string;
}

const Goals: React.FC = () => {
  const [selectedLevel, setSelectedLevel] = useState<string>('annual');
  const [goals, setGoals] = useState<Goal[]>([
    {
      id: '1',
      title: 'Build a Thriving Coaching Business',
      description: 'Create a sustainable coaching practice that helps 100+ people annually',
      level: 'vision',
      status: 'in-progress',
      progress: 45
    },
    {
      id: '2',
      title: 'Launch Coach Pack Platform',
      description: 'Develop and launch the complete Coach Pack application',
      level: 'annual',
      status: 'in-progress',
      progress: 75,
      dueDate: '2025-12-31',
      parentId: '1'
    },
    {
      id: '3',
      title: 'Complete MVP Development',
      description: 'Finish all core features and user testing',
      level: 'quarterly',
      status: 'in-progress',
      progress: 85,
      dueDate: '2025-03-31',
      parentId: '2'
    },
    {
      id: '4',
      title: 'Finalize Vision Board Feature',
      description: 'Complete development and testing of vision board functionality',
      level: 'weekly',
      status: 'completed',
      progress: 100,
      dueDate: '2025-01-15',
      parentId: '3'
    },
    {
      id: '5',
      title: 'Code Goals Component',
      description: 'Implement the hierarchical goals system',
      level: 'daily',
      status: 'in-progress',
      progress: 90,
      dueDate: '2025-01-10',
      parentId: '4'
    }
  ]);

  const levels = [
    { 
      id: 'vision', 
      title: 'Life Vision', 
      description: 'Your overarching life purpose and direction',
      color: 'purple',
      icon: Target
    },
    { 
      id: 'annual', 
      title: 'Annual Goals', 
      description: 'Major objectives for this year',
      color: 'blue',
      icon: Calendar
    },
    { 
      id: 'quarterly', 
      title: '90-Day Goals', 
      description: 'Quarterly milestones and projects',
      color: 'teal',
      icon: TrendingUp
    },
    { 
      id: 'weekly', 
      title: 'Weekly Goals', 
      description: 'This week\'s priorities and tasks',
      color: 'orange',
      icon: Clock
    },
    { 
      id: 'daily', 
      title: 'Daily Actions', 
      description: 'Today\'s specific tasks and actions',
      color: 'green',
      icon: CheckCircle2
    }
  ];

  const getColorClasses = (color: string, variant: 'bg' | 'text' | 'border' = 'text') => {
    const colorMap = {
      purple: { bg: 'bg-purple-50 border-purple-200', text: 'text-purple-600', border: 'border-purple-500' },
      blue: { bg: 'bg-blue-50 border-blue-200', text: 'text-blue-600', border: 'border-blue-500' },
      teal: { bg: 'bg-teal-50 border-teal-200', text: 'text-teal-600', border: 'border-teal-500' },
      orange: { bg: 'bg-orange-50 border-orange-200', text: 'text-orange-600', border: 'border-orange-500' },
      green: { bg: 'bg-green-50 border-green-200', text: 'text-green-600', border: 'border-green-500' }
    };
    return colorMap[color as keyof typeof colorMap]?.[variant] || colorMap.purple[variant];
  };

  const getGoalsForLevel = (level: string) => {
    return goals.filter(goal => goal.level === level);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'in-progress':
        return <Circle className="w-5 h-5 text-blue-500" />;
      default:
        return <Circle className="w-5 h-5 text-slate-400" />;
    }
  };

  const addNewGoal = () => {
    const newGoal: Goal = {
      id: Date.now().toString(),
      title: 'New Goal',
      description: 'Click to edit description',
      level: selectedLevel as any,
      status: 'not-started',
      progress: 0
    };
    setGoals(prev => [...prev, newGoal]);
  };

  const toggleGoalStatus = (goalId: string) => {
    setGoals(prev => prev.map(goal => 
      goal.id === goalId 
        ? { 
            ...goal, 
            status: goal.status === 'completed' ? 'in-progress' : 'completed',
            progress: goal.status === 'completed' ? goal.progress : 100
          }
        : goal
    ));
  };

  const selectedLevelData = levels.find(level => level.id === selectedLevel);
  const levelGoals = getGoalsForLevel(selectedLevel);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Goals</h1>
          <p className="text-slate-600 mt-2">
            Transform your vision into actionable steps across multiple time horizons
          </p>
        </div>
        <button
          onClick={addNewGoal}
          className="flex items-center space-x-2 px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>New Goal</span>
        </button>
      </div>

      {/* Level Navigation */}
      <div className="flex flex-wrap gap-2">
        {levels.map((level) => {
          const Icon = level.icon;
          const isSelected = selectedLevel === level.id;
          
          return (
            <button
              key={level.id}
              onClick={() => setSelectedLevel(level.id)}
              className={`flex items-center space-x-2 px-4 py-3 rounded-lg border transition-all duration-200 ${
                isSelected 
                  ? `${getColorClasses(level.color, 'bg')} ${getColorClasses(level.color, 'border')} ${getColorClasses(level.color, 'text')}` 
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-4 h-4" />
              <div className="text-left">
                <div className="font-medium text-sm">{level.title}</div>
                <div className="text-xs opacity-75">{getGoalsForLevel(level.id).length} goals</div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Current Level Overview */}
      {selectedLevelData && (
        <div className={`rounded-2xl border p-6 ${getColorClasses(selectedLevelData.color, 'bg')}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className={`p-3 bg-white rounded-lg ${getColorClasses(selectedLevelData.color, 'text')}`}>
                <selectedLevelData.icon className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-slate-900">{selectedLevelData.title}</h2>
                <p className="text-slate-600">{selectedLevelData.description}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-slate-900">{levelGoals.length}</div>
              <div className="text-sm text-slate-600">goals</div>
            </div>
          </div>
        </div>
      )}

      {/* Goals List */}
      <div className="space-y-4">
        {levelGoals.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-slate-200">
            <Target className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-900 mb-2">No Goals Yet</h3>
            <p className="text-slate-600 mb-4">Start by adding your first goal for this level</p>
            <button
              onClick={addNewGoal}
              className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              Add Your First Goal
            </button>
          </div>
        ) : (
          levelGoals.map((goal) => (
            <div
              key={goal.id}
              className="bg-white rounded-xl p-6 shadow-sm border border-slate-200 hover:shadow-md transition-all duration-200"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start space-x-3 flex-1">
                  <button
                    onClick={() => toggleGoalStatus(goal.id)}
                    className="mt-1 hover:scale-110 transition-transform"
                  >
                    {getStatusIcon(goal.status)}
                  </button>
                  <div className="flex-1">
                    <h3 className={`text-lg font-semibold mb-1 ${
                      goal.status === 'completed' ? 'text-slate-500 line-through' : 'text-slate-900'
                    }`}>
                      {goal.title}
                    </h3>
                    <p className="text-slate-600 text-sm mb-3">{goal.description}</p>
                    
                    {/* Progress Bar */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-slate-500">Progress</span>
                        <span className="font-medium text-slate-700">{goal.progress}%</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full transition-all duration-300 ${
                            selectedLevelData ? 
                              `bg-gradient-to-r ${
                                selectedLevelData.color === 'purple' ? 'from-purple-500 to-purple-600' :
                                selectedLevelData.color === 'blue' ? 'from-blue-500 to-blue-600' :
                                selectedLevelData.color === 'teal' ? 'from-teal-500 to-teal-600' :
                                selectedLevelData.color === 'orange' ? 'from-orange-500 to-orange-600' :
                                'from-green-500 to-green-600'
                              }` : 'bg-purple-500'
                          }`}
                          style={{ width: `${goal.progress}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4 ml-4">
                  {goal.dueDate && (
                    <div className="text-right">
                      <div className="text-xs text-slate-500">Due Date</div>
                      <div className="text-sm font-medium text-slate-700">
                        {new Date(goal.dueDate).toLocaleDateString()}
                      </div>
                    </div>
                  )}
                  {goal.status === 'completed' && (
                    <Award className="w-6 h-6 text-yellow-500" />
                  )}
                </div>
              </div>

              {/* Goal Actions */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                <div className="flex items-center space-x-2 text-sm">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    goal.status === 'completed' ? 'bg-green-100 text-green-700' :
                    goal.status === 'in-progress' ? 'bg-blue-100 text-blue-700' :
                    'bg-slate-100 text-slate-600'
                  }`}>
                    {goal.status === 'completed' ? 'Completed' :
                     goal.status === 'in-progress' ? 'In Progress' :
                     'Not Started'}
                  </span>
                  {selectedLevelData && (
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getColorClasses(selectedLevelData.color, 'bg')} ${getColorClasses(selectedLevelData.color, 'text')}`}>
                      {selectedLevelData.title}
                    </span>
                  )}
                </div>
                <button className="text-slate-400 hover:text-slate-600 text-sm">
                  Edit Goal
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Goal Insights */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Goal Insights</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">
              {goals.filter(g => g.status === 'completed').length}
            </div>
            <div className="text-sm text-slate-600">Completed</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">
              {goals.filter(g => g.status === 'in-progress').length}
            </div>
            <div className="text-sm text-slate-600">In Progress</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">
              {Math.round(goals.reduce((sum, goal) => sum + goal.progress, 0) / goals.length) || 0}%
            </div>
            <div className="text-sm text-slate-600">Average Progress</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Goals;