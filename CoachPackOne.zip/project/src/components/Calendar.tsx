import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, Filter, Grid3X3, List, Calendar as CalendarIcon } from 'lucide-react';

interface CalendarEvent {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  category: 'business' | 'health' | 'personal' | 'family';
  duration: number;
}

const Calendar: React.FC = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState<'month' | 'week' | 'day'>('month');
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  
  const [events, setEvents] = useState<CalendarEvent[]>([
    {
      id: '1',
      title: 'Morning Workout',
      description: 'Gym session focusing on strength training',
      date: '2025-01-10',
      time: '07:00',
      category: 'health',
      duration: 60
    },
    {
      id: '2',
      title: 'Client Strategy Call',
      description: 'Quarterly planning session with key client',
      date: '2025-01-10',
      time: '10:00',
      category: 'business',
      duration: 90
    },
    {
      id: '3',
      title: 'Family Dinner',
      description: 'Weekly family gathering',
      date: '2025-01-10',
      time: '18:00',
      category: 'family',
      duration: 120
    }
  ]);

  const categories = [
    { id: 'business', name: 'Business', color: 'bg-purple-500', textColor: 'text-purple-700', bgColor: 'bg-purple-50' },
    { id: 'health', name: 'Health', color: 'bg-green-500', textColor: 'text-green-700', bgColor: 'bg-green-50' },
    { id: 'personal', name: 'Personal', color: 'bg-blue-500', textColor: 'text-blue-700', bgColor: 'bg-blue-50' },
    { id: 'family', name: 'Family', color: 'bg-orange-500', textColor: 'text-orange-700', bgColor: 'bg-orange-50' }
  ];

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }
    
    return days;
  };

  const getEventsForDate = (date: Date | null) => {
    if (!date) return [];
    const dateString = date.toISOString().split('T')[0];
    return events.filter(event => event.date === dateString);
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const getCategoryData = (categoryId: string) => {
    return categories.find(cat => cat.id === categoryId) || categories[0];
  };

  const days = getDaysInMonth(currentDate);
  const monthYear = currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Action Calendar</h1>
          <p className="text-slate-600 mt-2">
            Schedule and track your daily actions aligned with your goals
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="flex items-center bg-slate-100 rounded-lg p-1">
            {['month', 'week', 'day'].map((viewType) => (
              <button
                key={viewType}
                onClick={() => setView(viewType as any)}
                className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                  view === viewType 
                    ? 'bg-white text-slate-900 shadow-sm' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {viewType.charAt(0).toUpperCase() + viewType.slice(1)}
              </button>
            ))}
          </div>
          <button className="flex items-center space-x-2 px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
            <Plus className="w-4 h-4" />
            <span>New Event</span>
          </button>
        </div>
      </div>

      {/* Calendar Navigation */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigateMonth('prev')}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-slate-600" />
          </button>
          <h2 className="text-xl font-semibold text-slate-900">{monthYear}</h2>
          <button
            onClick={() => navigateMonth('next')}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <ChevronRight className="w-5 h-5 text-slate-600" />
          </button>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Category Legend */}
          <div className="flex items-center space-x-3">
            {categories.map((category) => (
              <div key={category.id} className="flex items-center space-x-1">
                <div className={`w-3 h-3 rounded-full ${category.color}`} />
                <span className="text-sm text-slate-600">{category.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        {/* Days of Week Header */}
        <div className="grid grid-cols-7 border-b border-slate-200">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
            <div key={day} className="p-4 text-center font-medium text-slate-600 bg-slate-50">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Days */}
        <div className="grid grid-cols-7">
          {days.map((day, index) => {
            const dayEvents = day ? getEventsForDate(day) : [];
            const isToday = day && day.toDateString() === new Date().toDateString();
            const isSelected = selectedDate && day && day.toDateString() === selectedDate.toDateString();

            return (
              <div
                key={index}
                className={`min-h-24 p-2 border-r border-b border-slate-100 ${
                  day ? 'cursor-pointer hover:bg-slate-50' : 'bg-slate-25'
                } ${isSelected ? 'bg-purple-50' : ''}`}
                onClick={() => day && setSelectedDate(day)}
              >
                {day && (
                  <>
                    <div className={`text-sm font-medium mb-1 ${
                      isToday ? 'bg-purple-600 text-white w-6 h-6 rounded-full flex items-center justify-center' : 'text-slate-900'
                    }`}>
                      {day.getDate()}
                    </div>
                    <div className="space-y-1">
                      {dayEvents.slice(0, 2).map((event) => {
                        const categoryData = getCategoryData(event.category);
                        return (
                          <div
                            key={event.id}
                            className={`text-xs p-1 rounded ${categoryData.bgColor} ${categoryData.textColor} truncate`}
                          >
                            {event.time} {event.title}
                          </div>
                        );
                      })}
                      {dayEvents.length > 2 && (
                        <div className="text-xs text-slate-500">
                          +{dayEvents.length - 2} more
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Date Events */}
      {selectedDate && (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-900">
              {formatDate(selectedDate)}
            </h3>
            <button className="text-purple-600 hover:text-purple-700 text-sm font-medium">
              Add Event
            </button>
          </div>
          
          <div className="space-y-3">
            {getEventsForDate(selectedDate).length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <CalendarIcon className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>No events scheduled for this day</p>
              </div>
            ) : (
              getEventsForDate(selectedDate).map((event) => {
                const categoryData = getCategoryData(event.category);
                return (
                  <div
                    key={event.id}
                    className="flex items-start space-x-3 p-3 rounded-lg border border-slate-200 hover:shadow-sm transition-shadow"
                  >
                    <div className={`w-3 h-3 rounded-full ${categoryData.color} mt-2 flex-shrink-0`} />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-medium text-slate-900">{event.title}</h4>
                        <span className="text-sm text-slate-500">{event.time}</span>
                      </div>
                      <p className="text-sm text-slate-600 mb-2">{event.description}</p>
                      <div className="flex items-center space-x-3 text-xs text-slate-500">
                        <span className={`px-2 py-1 rounded-full ${categoryData.bgColor} ${categoryData.textColor}`}>
                          {categoryData.name}
                        </span>
                        <span>{event.duration} minutes</span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Calendar Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {categories.map((category) => {
          const categoryEvents = events.filter(event => event.category === category.id);
          const totalTime = categoryEvents.reduce((sum, event) => sum + event.duration, 0);
          
          return (
            <div key={category.id} className={`rounded-xl p-6 ${category.bgColor} border border-opacity-20`}>
              <div className="flex items-center justify-between mb-2">
                <h4 className={`font-semibold ${category.textColor}`}>{category.name}</h4>
                <div className={`w-3 h-3 rounded-full ${category.color}`} />
              </div>
              <div className="space-y-1">
                <div className={`text-2xl font-bold ${category.textColor}`}>
                  {categoryEvents.length}
                </div>
                <div className="text-sm opacity-75">
                  {Math.round(totalTime / 60)}h this month
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Calendar;