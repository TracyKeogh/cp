import React from 'react';
import { 
  BarChart3, 
  Heart, 
  ImageIcon, 
  Target, 
  Calendar as CalendarIcon,
  TrendingUp,
  Star,
  CheckCircle2
} from 'lucide-react';
import type { ViewType } from '../App';

interface DashboardProps {
  onNavigate: (view: ViewType) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const quickStats = [
    { label: 'Life Areas Assessed', value: '8/8', color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'Core Values Defined', value: '6', color: 'text-red-500', bg: 'bg-red-50' },
    { label: 'Vision Clarity', value: '85%', color: 'text-teal-600', bg: 'bg-teal-50' },
    { label: 'Goals Achieved', value: '12', color: 'text-orange-500', bg: 'bg-orange-50' },
  ];

  const actionCards = [
    {
      id: 'wheel',
      title: 'Wheel of Life',
      description: 'Assess your life balance across 8 key areas',
      icon: BarChart3,
      color: 'purple',
      progress: 100,
      status: 'Complete'
    },
    {
      id: 'values',
      title: 'Values Clarification',
      description: 'Define your core values through guided reflection',
      icon: Heart,
      color: 'red',
      progress: 75,
      status: 'In Progress'
    },
    {
      id: 'vision',
      title: 'Vision Board',
      description: 'Create visual representations of your goals',
      icon: ImageIcon,
      color: 'teal',
      progress: 60,
      status: 'In Progress'
    },
    {
      id: 'goals',
      title: 'Goal Setting',
      description: 'Break down your vision into actionable steps',
      icon: Target,
      color: 'orange',
      progress: 40,
      status: 'Started'
    },
    {
      id: 'calendar',
      title: 'Action Calendar',
      description: 'Schedule and track your daily actions',
      icon: CalendarIcon,
      color: 'indigo',
      progress: 20,
      status: 'Not Started'
    },
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      purple: 'text-purple-600 bg-purple-50 border-purple-200',
      red: 'text-red-500 bg-red-50 border-red-200',
      teal: 'text-teal-600 bg-teal-50 border-teal-200',
      orange: 'text-orange-500 bg-orange-50 border-orange-200',
      indigo: 'text-indigo-600 bg-indigo-50 border-indigo-200',
    };
    return colors[color as keyof typeof colors] || colors.purple;
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Welcome to Your Journey</h1>
            <p className="text-purple-100 text-lg">
              Transform your vision into reality with structured, intentional action.
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Star className="w-8 h-8 text-yellow-300" />
            <span className="text-2xl font-bold">4.8</span>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {quickStats.map((stat, index) => (
          <div key={index} className={`${stat.bg} rounded-xl p-6 border border-opacity-20`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">{stat.label}</p>
                <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
              </div>
              <TrendingUp className={`w-6 h-6 ${stat.color}`} />
            </div>
          </div>
        ))}
      </div>

      {/* Action Cards */}
      <div>
        <h2 className="text-2xl font-bold text-slate-900 mb-6">Your Coaching Journey</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {actionCards.map((card) => {
            const Icon = card.icon;
            const colorClasses = getColorClasses(card.color);
            
            return (
              <div
                key={card.id}
                className="bg-white rounded-xl p-6 shadow-sm border border-slate-200 hover:shadow-md transition-all duration-200 cursor-pointer group"
                onClick={() => onNavigate(card.id as ViewType)}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-3 rounded-lg ${colorClasses}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  {card.status === 'Complete' && (
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                  )}
                </div>
                
                <h3 className="text-lg font-semibold text-slate-900 mb-2 group-hover:text-purple-600 transition-colors">
                  {card.title}
                </h3>
                <p className="text-slate-600 text-sm mb-4">{card.description}</p>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">Progress</span>
                    <span className="font-medium text-slate-700">{card.progress}%</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full bg-gradient-to-r ${
                        card.color === 'purple' ? 'from-purple-500 to-purple-600' :
                        card.color === 'red' ? 'from-red-500 to-red-600' :
                        card.color === 'teal' ? 'from-teal-500 to-teal-600' :
                        card.color === 'orange' ? 'from-orange-500 to-orange-600' :
                        'from-indigo-500 to-indigo-600'
                      }`}
                      style={{ width: `${card.progress}%` }}
                    />
                  </div>
                  <span className={`text-xs font-medium ${
                    card.status === 'Complete' ? 'text-green-600' :
                    card.status === 'In Progress' ? 'text-blue-600' :
                    card.status === 'Started' ? 'text-orange-600' :
                    'text-slate-500'
                  }`}>
                    {card.status}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Recent Activity</h3>
        <div className="space-y-4">
          {[
            { action: 'Completed Wheel of Life assessment', time: '2 hours ago', color: 'purple' },
            { action: 'Updated core values ranking', time: '1 day ago', color: 'red' },
            { action: 'Added vision board image', time: '2 days ago', color: 'teal' },
            { action: 'Set quarterly goal milestone', time: '3 days ago', color: 'orange' },
          ].map((activity, index) => (
            <div key={index} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-slate-50 transition-colors">
              <div className={`w-2 h-2 rounded-full ${
                activity.color === 'purple' ? 'bg-purple-500' :
                activity.color === 'red' ? 'bg-red-500' :
                activity.color === 'teal' ? 'bg-teal-500' :
                'bg-orange-500'
              }`} />
              <div className="flex-1">
                <p className="text-sm font-medium text-slate-900">{activity.action}</p>
                <p className="text-xs text-slate-500">{activity.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;