import React from 'react';
import { Target, Sparkles } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Target className="w-8 h-8 text-purple-600" />
              <Sparkles className="w-4 h-4 text-orange-400 absolute -top-1 -right-1" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Coach Pack</h1>
              <p className="text-sm text-slate-600">Intentional Living Made Actionable</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="text-sm font-medium text-slate-900">Welcome back!</p>
              <p className="text-xs text-slate-500">Continue your journey</p>
            </div>
            <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full flex items-center justify-center">
              <span className="text-white font-semibold text-sm">CP</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;